public class Menu {
    private Player player;

    public Menu(Player player) {
        this.player = player;
    }

    public void display(Player player, Merchant merchant) {
        String tileName;
        switch (player.getCurrentTile()) {
            case 1:
                tileName = "Water";
                break;
            case 2:
            case 5:
                tileName = "Grassland";
                break;
            case 3:
                tileName = "Mountain";
                break;
            case 4:
                tileName = "Beach";
                break;
            case 6:
                tileName = "Tundra";
                break;
            case 7:
                tileName = "Forest";
                break;
            default: // 8
                tileName = "undefined";
                break;
        }

        System.out.println("+-----------------------------------------------------------+");
        System.out.println("|                            Menu                           |");
        System.out.println("+-----------------------------------------------------------+");
        System.out.printf("| Current Tile: %-44s|\n", tileName);
        System.out.println("| " +  player.getHunger() + "                                      |");
        System.out.println("| " +  player.getThirst() + "                                      |");
        System.out.printf("| Money: $%-50s|\n", merchant.getBalance());
        System.out.println("| Resources:                                                |");
        System.out.printf("|   Wood: %-50d|\n", player.getWood());
        System.out.printf("|   Stone: %-49d|\n", player.getStone());
        System.out.println("+-----------------------------------------------------------+");
    }
}
