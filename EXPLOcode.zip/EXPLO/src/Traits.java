import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class Traits {

    public Set<String> traitSet;

    public Traits() {
        traitSet = new HashSet<>();
    }

    public void assignTraits() {
        Random rand = new Random();
        int luck = rand.nextInt(100);
        int strength = rand.nextInt(100);
        int needs = rand.nextInt(100);
        int charisma = rand.nextInt(100);

        if (luck > 90) {
            traitSet.add("lucky");
        } else if (luck < 10) {
            traitSet.add("unlucky");
        }

        if (strength > 85) {
            traitSet.add("strong");
        } else if (strength < 15) {
            traitSet.add("weak");
        }

        if (charisma > 90) {
            traitSet.add("charismatic");
        }

        if (needs > 90) {
            traitSet.add("needy");
        }
    }

    public boolean hasTrait(String trait) {
        return traitSet.contains(trait);
    }

    public boolean isLucky(){
        return traitSet.contains("lucky");
    }

    public boolean isUnlucky(){
        return traitSet.contains("unlucky");
    }

    public boolean isStrong(){
        return traitSet.contains("strong");
    }

    public boolean isWeak(){
        return traitSet.contains("weak");
    }

    public boolean isCharismatic(){
        return traitSet.contains("charismatic");
    }

    public boolean isNeedy(){
        return traitSet.contains("needy");
    }

    public Set<String> getTraitSet() {
        return traitSet;
    }

}
