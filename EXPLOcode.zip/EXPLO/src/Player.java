import org.fusesource.jansi.Ansi;

import java.io.IOException;
import java.util.Random;

public class Player {
    private int x;
    private int y;
    private double hunger = 100; // full hunger at start
    private double thirst = 100; // full thirst at start
    private int[][] tiles;
    Resource wood = new Resource("Wood", 0);
    Resource stone = new Resource("Stone", 0);


    public String getUser(){
        String username = HomeScreen.getUsername();
        return username;
    }

    public int getWood(){
        int woodAmount = wood.getAmount();
        return(woodAmount);
    }

    public int getStone(){
        int stoneAmount = stone.getAmount();
        return(stoneAmount);
    }

    public void addStone(int amount){
        stone.addAmount(amount);
    }

    public void addWood(int amount){
        wood.addAmount(amount);
    }

    public String getHunger() {
        if (hunger == 100) {
            return "Hunger: [##########]";
        } else if (hunger >= 90) {
            return "Hunger: [#########-]";
        } else if (hunger >= 80) {
            return "Hunger: [########--]";
        } else if (hunger >= 70) {
            return "Hunger: [#######---]";
        } else if (hunger >= 60) {
            return "Hunger: [######----]";
        } else if (hunger >= 50) {
            return "Hunger: [#####-----]";
        } else if (hunger >= 40) {
            return "Hunger: [####------]";
        } else if (hunger >= 30) {
            return "Hunger: [###-------]";
        } else if (hunger >= 20) {
            return "Hunger: [##--------]";
        } else if (hunger >= 10) {
            return "Hunger: [#---------]";
        } else {
            return "Hunger: [----------]";
        }
    }

    public String getThirst() {
        if (thirst == 100) {
            return "Thirst: [##########]";
        } else if (thirst >= 90) {
            return "Thirst: [#########-]";
        } else if (thirst >= 80) {
            return "Thirst: [########--]";
        } else if (thirst >= 70) {
            return "Thirst: [#######---]";
        } else if (thirst >= 60) {
            return "Thirst: [######----]";
        } else if (thirst >= 50) {
            return "Thirst: [#####-----]";
        } else if (thirst >= 40) {
            return "Thirst: [####------]";
        } else if (thirst >= 30) {
            return "Thirst: [###-------]";
        } else if (thirst >= 20) {
            return "Thirst: [##--------]";
        } else if (thirst >= 10) {
            return "Thirst: [#---------]";
        } else {
            return "Thirst: [----------]";
        }
    }

    public Player(int[][] tiles) {
        Random random = new Random();
        int width = tiles.length;
        int height = tiles[0].length;
        int edgeDist = 30;
        // Find a valid position for the player
        boolean found = false;
        while (!found) {
            x = random.nextInt(width - (edgeDist*2)) + edgeDist; // Avoid edges of map
            y = random.nextInt(height - (edgeDist*2)) + edgeDist;
            if (tiles[x][y] != 1 && tiles[x][y] != 3) { // Avoid water and mountains
                found = true;
            }
        }

        this.tiles = tiles;
        //setting default resources:
        Resource wood = new Resource("Wood", 0);
        Resource stone = new Resource("Stone", 0);

    }

    public void increaseHunger(){
        hunger = hunger - 1.25;
        if (hunger < 0) {
            hunger = 0;
        }
    }

    public void increaseThirst(){
        thirst = thirst - 2;
        if (thirst < 0) {
            thirst = 0;
        }
    }

    public void decreaseThirst(){
        thirst = thirst + 25;
        if (thirst > 100) {
            thirst = 100;
        }
    }

    public void decreaseHunger(){
        hunger = hunger + 25;
        if (hunger > 100) {
            hunger = 100;
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getCurrentTile(){
        return tiles[getX()][getY()];
    }

    public void move(int dx, int dy) throws IOException, InterruptedException {
        System.out.print("\033[H\033[2J");
        System.out.flush();
        Main.clearConsole();
        int newX = x + dx;
        int newY = y + dy;
        if (newX >= 0 && newX < tiles.length && newY >= 0 && newY < tiles[0].length && tiles[newX][newY] != 1 && tiles[newX][newY] != 3) {
            x = newX;
            y = newY;
        }
        System.out.println(Ansi.ansi().eraseScreen());
        System.out.print("\033[2J\033[H");
        System.out.flush();
    }
}
