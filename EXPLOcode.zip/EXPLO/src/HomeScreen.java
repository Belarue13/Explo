import java.io.IOException;
import java.util.Scanner;

public class HomeScreen {
    public static final String ASCII_ART =
            "+-----------------------------------------------------+\n" +
            "|                     Welcome To:                     |\n" +
            "|                                                     |\n" +
            "|  ________  ____  ____  _______  _____       ___     |\n" +
            "| |_   __  ||_  _||_  _||_   __ \\|_   _|    .'   `.   |\n" +
            "|   | |_ \\_|  \\ \\  / /    | |__) | | |     /  .-.  \\  |\n" +
            "|   |  _| _    > `' <     |  ___/  | |   _ | |   | |  |\n" +
            "|  _| |__/ | _/ /'`\\ \\_  _| |_    _| |__/ |\\  `-'  /  |\n" +
            "| |________||____||____||_____|  |________| `.___.'   |\n" +
            "|                                                     |\n" +
            "|               A 4rkStudio Production                |\n" +
            "+-----------------------------------------------------+" ;

    private static String username;
    private static String worldSize;

    public HomeScreen() throws IOException, InterruptedException {
        System.out.println(ASCII_ART);
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter world size (Tiny, Small, Medium, Large, Huge):");
        worldSize = scanner.nextLine();
        while(!worldSize.equalsIgnoreCase("small") && !worldSize.equalsIgnoreCase("medium") && !worldSize.equalsIgnoreCase("large") && !worldSize.equalsIgnoreCase("tiny") && !worldSize.equalsIgnoreCase("huge")){
            System.out.print("\033[2J\033[H");
            System.out.flush();
            Main.clearConsole();
            System.out.println(ASCII_ART);
            System.out.println("Enter world size (Tiny, Small, Medium, Large, Huge):");
            worldSize = scanner.nextLine();
        }
        System.out.print("Enter your username: ");
        username = scanner.nextLine();
    }

    public String getTitle(){
        return ASCII_ART;
    }

    public static String getUsername() {
        return username;
    }

    public int getWorldSize(){
        if(worldSize.toLowerCase().equals("tiny")){
            return 75;
        } else if(worldSize.toLowerCase().equals("small")){
            return 100;
        } else if(worldSize.toLowerCase().equals("medium")){
            return 150;
        } else if(worldSize.toLowerCase().equals("large")){
            return 200;
        } else if(worldSize.toLowerCase().equals("huge")){
            return 250;
        } else {
            // if for any reason world size isn't any of the above expectations, set to medium
            return 150;
        }
    }
}
