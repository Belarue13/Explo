import java.util.Scanner;

public class HomeScreen {
    public static final String ASCII_ART =
            "+-----------------------------------------------------+\n" +
            "|                     Welcome To:                     |\n" +
            "|                                                     |\n" +
            "|  ________  ____  ____  _______  _____       ___     |\n" +
            "| |_   __  ||_  _||_  _||_   __ \\|_   _|    .'   `.   |\n" +
            "|   | |_ \\_|  \\ \\  / /    | |__) | | |     /  .-.  \\  |\n" +
            "|   |  _| _    > `' <     |  ___/  | |   _ | |   | |  |\n" +
            "|  _| |__/ | _/ /'`\\ \\_  _| |_    _| |__/ |\\  `-'  /  |\n" +
            "| |________||____||____||_____|  |________| `.___.'   |\n" +
            "|                                                     |\n" +
            "|                                                     |\n" +
            "+-----------------------------------------------------+" ;

    private static String username;

    public HomeScreen() {
        System.out.println(ASCII_ART);
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your username: ");
        username = scanner.nextLine();
    }

    public String getTitle(){
        return ASCII_ART;
    }

    public static String getUsername() {
        return username;
    }
}
