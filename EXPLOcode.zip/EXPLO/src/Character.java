import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Character {
    public ArrayList<String> inventory = new ArrayList<>();
    public int fishingXP;
    public int fishingLv = 0;
    public int miningXP;
    public int miningLv = 0;
    public int choppingXP;
    public int choppingLv = 0;
    public int diggingXP;
    public int diggingLv = 0;

    public void addItemToInventory(String item) {
        inventory.add(item);
    }

    public void removeItemFromInventory(String item) {
        inventory.remove(item);
    }

    public ArrayList<String> getInventory() {
        return inventory;
    }

    public void addXP(String type, int amount){
        if (type.equals("fishing")){
            for(int i = amount; i != 0; i--){
                fishingXP++;
                if(fishingXP >= 20){
                    fishingLv++;
                    fishingXP =-20;
                }
            }
        }
        if (type.equals("mining")){
            for(int i = amount; i != 0; i--){
                miningXP++;
                if(miningXP >= 20){
                    miningLv++;
                    miningXP =-20;
                }
            }
        }
        if (type.equals("chopping")){
            for(int i = amount; i != 0; i--){
                choppingXP++;
                if(choppingXP >= 20){
                    choppingLv++;
                    choppingXP =-20;
                }
            }
        }
        if (type.equals("digging")){
            for(int i = amount; i != 0; i--){
                diggingXP++;
                if(diggingXP >= 20){
                    diggingLv++;
                    diggingXP =-20;
                }
            }
        }
    }

    public int getFishingLv(){
        return fishingLv;
    }

    public int getMiningLv(){
        return miningLv;
    }

    public int getChoppingLv(){
        return choppingLv;
    }

    public int getDiggingLv(){return diggingLv;}

    public void characterMenu(Player player, Traits traits){
        System.out.println("+-----------------------------------------------------------+");
        System.out.println("|                         Character                         |");
        System.out.println("+-----------------------------------------------------------+");
        System.out.printf("| Name: %-52s|\n", player.getUser());
        System.out.printf("| Chopping Level: %-42d|\n", choppingLv);
        System.out.printf("| Mining Level: %-44d|\n", miningLv);
        System.out.printf("| Digging Level: %-43d|\n", diggingLv);
        System.out.printf("| Fishing Level: %-43d|\n", fishingLv);
        System.out.println("| Traits:                                                   |");
        // Print the traits
        if (traits.getTraitSet().isEmpty()) {
            System.out.println("| No traits found.                                          |");
        } else {
            for (String trait : traits.getTraitSet()) {
                System.out.printf("| %-58s|\n", trait);
            }
        }
        System.out.println("+-----------------------------------------------------------+");
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter \"B\" or \"Back\" to return");
        String input = scan.nextLine();
        while (!input.equalsIgnoreCase("back") && !input.equalsIgnoreCase("b")) {
            System.out.println("Enter \"Back\" to return");
            input = scan.nextLine();
        }
    }

    public void inventoryMenu(){
        System.out.println("+-----------------------------------------------------------+");
        System.out.println("|                         Inventory                         |");
        System.out.println("+-----------------------------------------------------------+");
        Map<String, Integer> itemMap = new HashMap<>();
        for (String item : inventory) {
            itemMap.put(item, itemMap.getOrDefault(item, 0) + 1);
        }
        for (Map.Entry<String, Integer> entry : itemMap.entrySet()) {
            String item = (entry.getKey() + " x" + entry.getValue());
            System.out.printf("| %-58s|" , item);
            System.out.println();
        }
        if( itemMap.isEmpty()){
            System.out.println("| Empty                                                     |");
        }
        System.out.println("+-----------------------------------------------------------+");
    }

}
