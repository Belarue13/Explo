import java.io.IOException;
import java.util.Locale;
import java.util.Scanner;
import org.fusesource.jansi.Ansi;
import org.fusesource.jansi.AnsiConsole;

public class Main {

    private static boolean canMove(int x, int y, int[][] tiles) {
        return x >= 0 && x < tiles.length && y >= 0 && y < tiles[0].length && tiles[x][y] != 1 && tiles[x][y] != 3;
    }

    public static void clearConsole() throws IOException, InterruptedException {
        String os = System.getProperty("os.name");
        if (os.contains("Windows")) {
            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
        } else {
            Runtime.getRuntime().exec("clear");
        }
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        AnsiConsole.systemInstall();
        HomeScreen homeScreen = new HomeScreen();
        String username = homeScreen.getUsername();
        Merchant merchant = new Merchant();
        System.out.println(Ansi.ansi().eraseScreen());
        System.out.print("\033[2J\033[H");
        System.out.flush();
        clearConsole();
        System.out.println(homeScreen.getTitle());
        System.out.println("Welcome to EXPLO " + username + "!");
        System.out.println("Generating World, this can take a while...");
        WorldGenerator generator = new WorldGenerator(150, 150);
        generator.generate();
        MiniMap miniMap = new MiniMap(generator);

        Player player = new Player(generator.getTiles());
        Menu menu = new Menu(player);

        Character character = new Character();
        Actions actions = new Actions();

        System.out.println("Use WASD to move, Q to quit");

        Scanner scanner = new Scanner(System.in);
        int playerX = player.getX();
        int playerY = player.getY();

        while (true) {
            System.out.print("\033[H\033[2J");
            System.out.flush();
            clearConsole();
            generator.print(player);
            menu.display(player, merchant);
            System.out.println("Use WASD to move, Stay to Stay, M for Map, F for Actions, \nC for Character, I for Inventory, T for Merchant, Q for Quit");
            // Move player
            int dx = 0;
            int dy = 0;
            String input = scanner.nextLine();
            if (input.equalsIgnoreCase("Q")) {
                break;
            } else if (input.equalsIgnoreCase("W")) {
                dy = -1;
                player.increaseThirst();
                player.increaseHunger();
            } else if (input.equalsIgnoreCase("A")) {
                dx = -1;
                player.increaseThirst();
                player.increaseHunger();
            } else if (input.equalsIgnoreCase("S")) {
                dy = 1;
                player.increaseThirst();
                player.increaseHunger();
            } else if (input.equalsIgnoreCase("D")) {
                dx = 1;
                player.increaseThirst();
                player.increaseHunger();
            } else if (input.equalsIgnoreCase("Stay")) {
                dx = 0;
                // Only decreasing thirst. Hunger is based on action
                player.increaseThirst();
            } else if (input.equalsIgnoreCase("M") || input.equalsIgnoreCase("MAP")) {
                System.out.print("\033[H\033[2J");
                System.out.flush();
                clearConsole();
                miniMap.print(playerX, playerY, generator);
            } else if(input.equalsIgnoreCase("F") || input.equalsIgnoreCase("ACTIONS")){
                System.out.print("\033[H\033[2J");
                System.out.flush();
                clearConsole();
                generator.print(player);
                actions.actionMenu(player, generator, character);
            } else if(input.equalsIgnoreCase("C") || input.equalsIgnoreCase("Character")){
                System.out.print("\033[H\033[2J");
                System.out.flush();
                clearConsole();
                generator.print(player);
                character.characterMenu(player);
            } else if(input.equalsIgnoreCase("I") || input.equalsIgnoreCase("Inventory")){
                System.out.print("\033[H\033[2J");
                System.out.flush();
                clearConsole();
                generator.print(player);
                character.inventoryMenu();
                Scanner scan = new Scanner(System.in);
                System.out.println("Enter \"B\" or \"Back\" to return");
                input = scan.nextLine();
                while (!input.equalsIgnoreCase("back") && !input.equalsIgnoreCase("b")) {
                    System.out.println("Enter \"Back\" to return");
                    input = scan.nextLine();
                }
            }else if(input.equalsIgnoreCase("T") || input.equalsIgnoreCase("Merchant")){
                System.out.print("\033[H\033[2J");
                System.out.flush();
                clearConsole();
                merchant.sell(character);
            }
            playerX = player.getX();
            playerY = player.getY();

            if (canMove(playerX + dx, playerY + dy, generator.getTiles())) {
                player.move(dx, dy);
            }
        }
    }
}
