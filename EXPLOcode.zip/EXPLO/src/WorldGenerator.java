import java.util.Random;
import java.util.Locale;

import org.fusesource.jansi.Ansi;
import org.fusesource.jansi.AnsiConsole;

public class WorldGenerator {
    private int width;
    private int height;
    private int[][] tiles;
    private Random random;

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }

    public WorldGenerator(int width, int height) {
        this.width = width;
        this.height = height;
        this.tiles = new int[width][height];
        this.random = new Random();
    }

    public int getTile(int x, int y) {
        if (x < 0 || x >= width || y < 0 || y >= height) {
            return 0; // out of bounds, return empty tile
        }
        return tiles[x][y];
    }

    public int[][] getTiles() {
        return tiles;
    }

    private void adjustTiles() {
        // Iterate through every tile
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                // Check for adjacent tiles of different types
                boolean hasWater = false;
                boolean hasDesert = false;
                boolean hasTundra = false;
                boolean hasGrassland = false;
                boolean hasForest = false;

                for (int dx = -1; dx <= 1; dx++) {
                    for (int dy = -1; dy <= 1; dy++) {
                        if (dx == 0 && dy == 0) continue; // Skip center tile

                        int adjX = x + dx;
                        int adjY = y + dy;

                        if (adjX < 0 || adjX >= width || adjY < 0 || adjY >= height)
                            continue; // Skip out-of-bounds tiles

                        if (tiles[adjX][adjY] == 1) hasWater = true;
                        if (tiles[adjX][adjY] == 4) hasDesert = true;
                        if (tiles[adjX][adjY] == 6) hasTundra = true;
                        if (tiles[adjX][adjY] == 2) hasGrassland = true;
                        if (tiles[adjX][adjY] == 5) hasForest = true;
                    }
                }

                /*
                1: Water
                2: Grassland
                3: Mountain
                4: Beach
                5: Grassland2
                6: Tundra
                7: Forest
                */
                int tileType = tiles[x][y];
                double adjChance = 0.8;
                // Adjust tile type based on adjacent tile types

                if (tileType == 2 && hasWater && countAdjacentTiles(x, y, 1) >= 4) {
                    tiles[x][y] = 1;
                } else if (tileType == 1 && hasForest && random.nextDouble() < .8) {
                    tiles[x][y] = 2;
                } else if (tileType == 1 && hasDesert && random.nextDouble() < adjChance) {
                    tiles[x][y] = 4;
                } else if (tileType == 1 && hasTundra && random.nextDouble() < adjChance) {
                    tiles[x][y] = 6;
                } else if (tileType == 2 && hasWater) {
                    tiles[x][y] = 4; // Add beach
                } else if (tileType == 3 && hasWater) {
                    tiles[x][y] = 1;
                } else if (tileType == 4 && hasWater) {
                    tiles[x][y] = 1;
                } else if (tileType == 4 && hasForest && random.nextDouble() < adjChance) {
                    tiles[x][y] = 2;
                } else if (tileType == 4 && hasTundra && random.nextDouble() < adjChance) {
                    tiles[x][y] = 6;
                } else if (tileType == 5 && hasWater) {
                    tiles[x][y] = 4;
                } else if (tileType == 6 && hasGrassland && random.nextDouble() < adjChance) {
                    tiles[x][y] = 2;
                } else if (tileType == 6 && hasWater) {
                    tiles[x][y] = 1;
                } else if (tileType == 7 && hasWater) {
                    tiles[x][y] = 1;
                }
                // Final Adjustments
                for (int i = 0; i < 250; i++) {
                    if (tileType == 4 && (countAdjacentTiles(x, y, 1) >= 2)) {
                        tiles[x][y] = 1;
                    }
                    if (tileType == 4 && (countAdjacentTiles(x, y, 5) >= 4)) {
                        tiles[x][y] = 2;
                    }
                    if (tileType == 4 && (countAdjacentTiles(x, y, 2) >= 4)) {
                        tiles[x][y] = 2;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 3) >= 1)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 7 && (countAdjacentTiles(x, y, 3) >= 2)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 3) >= 2)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 4 && (countAdjacentTiles(x, y, 3) >= 2)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 2) >= 2)) {
                        tiles[x][y] = 2;
                    }
                    if (tileType == 3 && (countAdjacentTiles(x, y, 5) >= 2)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 3 && (countAdjacentTiles(x, y, 7) >= 2)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 4 && (countAdjacentTiles(x, y, 1) >= 2)) {
                        tiles[x][y] = 1;
                    }
                    if (tileType == 4 && (countAdjacentTiles(x, y, 1) >= 2) && (countAdjacentTiles(x, y, 4) >= 2)) {
                        tiles[x][y] = 1;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 6) >= 1)) {
                        tiles[x][y] = 6;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 3) >= 2)) {
                        tiles[x][y] = 6;
                    }
                    if (tileType == 7 && (countAdjacentTiles(x, y, 3) >= 2)) {
                        tiles[x][y] = 6;
                    }
                    if (tileType == 4 && (countAdjacentTiles(x, y, 7) >= 3) && (countAdjacentTiles(x, y, 1) <= 1)) {
                        tiles[x][y] = 2;
                    }
                    if (tileType == 4 && (countAdjacentTiles(x, y, 5) >= 3) && (countAdjacentTiles(x, y, 1) <= 1)) {
                        tiles[x][y] = 2;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 3) >= 2)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 7 && (countAdjacentTiles(x, y, 3) >= 2)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 3) >= 1) && (countAdjacentTiles(x, y, 5) >= 2)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 4 && (countAdjacentTiles(x, y, 1) >= 4)) {
                        tiles[x][y] = 1;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 2) >= 4)) {
                        tiles[x][y] = 2;
                    }
                    if (tileType == 7 && (countAdjacentTiles(x, y, 2) >= 4)) {
                        tiles[x][y] = 2;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 5) >= 5)) {
                        tiles[x][y] = 5;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 7) >= 5)) {
                        tiles[x][y] = 7;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 2) >= 5)) {
                        tiles[x][y] = 2;
                    }
                    if (tileType == 7 && (countAdjacentTiles(x, y, 2) >= 5)) {
                        tiles[x][y] = 2;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 5) >= 6)) {
                        tiles[x][y] = 5;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 2) >= 5)) {
                        tiles[x][y] = 2;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 5) >= 7)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 7) >= 7)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 7) >= 3) && (countAdjacentTiles(x, y, 5) >= 3)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 7) >= 3) && (countAdjacentTiles(x, y, 3) >= 1)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 5) >= 3) && (countAdjacentTiles(x, y, 3) >= 1)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 3) >= 2) && (countAdjacentTiles(x, y, 6) >= 1)) {
                        tiles[x][y] = 6;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 6) >= 2) && (countAdjacentTiles(x, y, 3) >= 1)) {
                        tiles[x][y] = 6;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 6) >= 2) && (countAdjacentTiles(x, y, 3) >= 1)) {
                        tiles[x][y] = 6;
                    }
                    if (tileType == 7 && (countAdjacentTiles(x, y, 6) >= 2) && (countAdjacentTiles(x, y, 3) >= 1)) {
                        tiles[x][y] = 6;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 6) >= 1) && (countAdjacentTiles(x, y, 3) >= 2)) {
                        tiles[x][y] = 6;
                    }
                    if (tileType == 7
                            && (countAdjacentTiles(x, y, 6) >= 1) && (countAdjacentTiles(x, y, 3) >= 2)) {
                        tiles[x][y] = 6;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 3) >= 6)) {
                        tiles[x][y] = 6;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 3) >= 6)) {
                        tiles[x][y] = 6;
                    }
                    if (tileType == 7 && (countAdjacentTiles(x, y, 3) >= 6)) {
                        tiles[x][y] = 6;
                    }
                    if (tileType == 7 && (countAdjacentTiles(x, y, 2) >= 7)) {
                        tiles[x][y] = 2;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 2) >= 3)) {
                        tiles[x][y] = 2;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 3) >= 4)) {
                        tiles[x][y] = 3;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 3) >= 5)) {
                        tiles[x][y] = 6;
                    }
                    if (tileType == 6 && (countAdjacentTiles(x, y, 3) == 0)) {
                        tiles[x][y] = 2;
                    }
                    if (tileType == 2 && (countAdjacentTiles(x, y, 7) >= 5)) {
                        tiles[x][y] = 7;
                    }
                    if (tileType == 5 && (countAdjacentTiles(x, y, 7) >= 5)) {
                        tiles[x][y] = 7;
                    }
                }
            }
        }
    }

    private double interpolate(double a, double b, double x) {
        double ft = x * Math.PI;
        double f = (1 - Math.cos(ft)) * 0.5;
        return a * (1 - f) + b * f;
    }


    private double smoothedNoise(int x, int y) {
        double corners = (noise(x - 1, y - 1) + noise(x + 1, y - 1) + noise(x - 1, y + 1) + noise(x + 1, y + 1)) / 16;
        double sides = (noise(x - 1, y) + noise(x + 1, y) + noise(x, y - 1) + noise(x, y + 1)) / 8;
        double center = noise(x, y) / 4;
        return corners + sides + center;
    }

    private double interpolateNoise(double x, double y) {
        int intX = (int) x;
        int intY = (int) y;
        double fractionalX = x - intX;
        double fractionalY = y - intY;

        double v1 = smoothedNoise(intX, intY);
        double v2 = smoothedNoise(intX + 1, intY);
        double v3 = smoothedNoise(intX, intY + 1);
        double v4 = smoothedNoise(intX + 1, intY + 1);

        double i1 = interpolate(v1, v2, fractionalX);
        double i2 = interpolate(v3, v4, fractionalX);

        double perlin = perlinNoise(x, y, 2, 0.4);

        return interpolate(interpolate(i1, i2, fractionalY), perlin, 0.5);
    }


    public void generate() {
        boolean validMap = false;
        while (!validMap) {
            // Generate terrain using Perlin noise
            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    double noiseValue = interpolateNoise(x * 0.01, y * 0.01);
                    int elevation = (int) (noiseValue * 70);

                    if (elevation < 16) {
                        tiles[x][y] = 1; // Water
                    } else if (elevation < 24) {
                        tiles[x][y] = 4; // Beach
                    } else if (elevation < 52) {
                        double temperature = interpolateNoise(x * 0.05, y * 0.05) * 2 - 1;
                        if (temperature < -0.49) {
                            tiles[x][y] = 6; // Tundra
                        } else if (temperature < 0.05) {
                            tiles[x][y] = 7; // Forest
                        } else if (temperature < 0.5) {
                            tiles[x][y] = 2; // Grassland
                        } else {
                            tiles[x][y] = 3; // Desert
                        }
                    } else if (elevation < 100) {
                        tiles[x][y] = 3; // Mountain
                    }
                }
            }

            // Adjust tiles based on adjacent tiles
            adjustTiles();

            // Random replace Grass with...
            for (int i = 0; i < 500; i++) {
                int x = random.nextInt(width);
                int y = random.nextInt(height);

                if (tiles[x][y] == 2) {
                    tiles[x][y] = 5;
                }
            }
            // Check percentage of tiles to check map validity
            int totalTiles = width * height;
            int waterTiles = countTiles(1);
            int mountainTiles = countTiles(3);
            double waterPercentage = (double) waterTiles / totalTiles;
            double mountainPercentage = (double) mountainTiles / totalTiles;
            if (waterPercentage >= 0.04 && waterPercentage <= 0.35 && mountainPercentage >= 0.025 && mountainPercentage <= 0.20) {
                validMap = true;
            }
        }
        System.out.println();
    }

    public int getGrass(){
        return countTiles(2)+countTiles(5);
    }

    public int getWater(){
        return countTiles(1);
    }

    public int getMountains(){
        return countTiles(3);
    }

    public int getForests(){
        return countTiles(7);
    }

    public int getTundras(){
        return countTiles(6);
    }

    public int getBeaches(){
        return countTiles(4);
    }

    public int getTotalTiles(){
        return width*height;
    }

    private int countAdjacentTiles(int x, int y, int tileType) {
        int count = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                if (dx == 0 && dy == 0) continue; // Skip center tile

                int adjX = x + dx;
                int adjY = y + dy;

                if (adjX < 0 || adjX >= width || adjY < 0 || adjY >= height)
                    continue; // Skip out-of-bounds tiles

                if (tiles[adjX][adjY] == tileType) {
                    count++;
                }
            }
        }
        return count;
    }


    // Helper method to count the number of tiles of a given type
    private int countTiles(int type) {
        int count = 0;
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (tiles[x][y] == type) {
                    count++;
                }
            }
        }
        return count;
    }

    public void print(Player player) {
        // Set player view size
        int vsY = 15;
        int vsX = 30;
        // Calculate the boundaries of the grid
        int startX = Math.max(0, player.getX() - (vsX - 1) / 2);
        int startY = Math.max(0, player.getY() - (vsY - 1) / 2);
        int endX = Math.min(width - 1, player.getX() + (vsX - 1) / 2);
        int endY = Math.min(height - 1, player.getY() + (vsY - 1) / 2);

        // Print the grid
        System.out.println("+-----------------------------------------------------------+");
        for (int y = startY; y <= endY; y++) {
            System.out.print("| ");
            for (int x = startX; x <= endX; x++) {
                if ((x == player.getX() && y == player.getY())) {
                    System.out.print((char) 1 + " ");
                } else {
                    switch (tiles[x][y]) {
                        case 1: // Water
                            System.out.print(Ansi.ansi().fgCyan().a("~ ")); // blue background
                            break;
                        case 2: // Grassland
                            System.out.print(Ansi.ansi().fgBright(Ansi.Color.GREEN).a(", ")); // light green background
                            break;
                        case 3: // Mountain
                            System.out.print(Ansi.ansi().fgRgb(100, 100, 100).a("^ ")); // gray background
                            break;
                        case 4: // Beach
                            System.out.print(Ansi.ansi().fgYellow().a("# ")); // yellow background
                            break;
                        case 5: // Grassland2
                            System.out.print(Ansi.ansi().fgBright(Ansi.Color.GREEN).a(". ")); // green background
                            break;
                        case 6: // Tundra
                            System.out.print(Ansi.ansi().fgRgb(255, 255, 255).a("* ")); // white background
                            break;
                        case 7: // Forest
                            System.out.print(Ansi.ansi().fgBright(Ansi.Color.GREEN).a("t ")); // green background
                            break;
                        default:
                            System.out.print(Ansi.ansi().bgMagenta().a("  ")); // Unknown
                            break;
                    }
                    System.out.print(Ansi.ansi().reset().toString());
                }
            }
            System.out.println("|");
        }
    }


    private double perlinNoise(double x, double y, int octaves, double persistence) {
        double total = 0;
        double amplitude = persistence * 2;
        double frequency = 2;
        double maxValue = 0;  // Used for normalizing result to 0.0 - 1.0 range
        for (int i = 0; i < octaves; i++) {
            total += noise(x * frequency, y * frequency) * amplitude;
            maxValue += amplitude;
            amplitude *= persistence;
            frequency *= 2;
        }
        return total / maxValue;
    }

    private double noise(double x, double y) {
        return random.nextDouble();
    }
}
