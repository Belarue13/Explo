import org.fusesource.jansi.Ansi;

import java.util.Scanner;

public class MiniMap {
    private int[][] tiles;
    public MiniMap(WorldGenerator world) {
        int scale = 6;
        tiles = new int[world.getWidth() / scale][world.getHeight() / scale];
        for (int x = 0; x < tiles.length; x++) {
            for (int y = 0; y < tiles[0].length; y++) {
                int startX = x * scale;
                int startY = y * scale;
                int endX = startX + scale - 1;
                int endY = startY + scale - 1;
                int[] counts = new int[8];
                for (int i = startX; i <= endX; i++) {
                    for (int j = startY; j <= endY; j++) {
                        counts[world.getTile(i, j)]++;
                    }
                }
                int mostCommonTile = 0;
                int highestCount = 0;
                for (int i = 1; i < counts.length; i++) {
                    if (counts[i] > highestCount) {
                        mostCommonTile = i;
                        highestCount = counts[i];
                    }
                }
                tiles[x][y] = mostCommonTile;
            }
        }
    }

    public void print(int playerX, int playerY, WorldGenerator world) {
        int scale = 6;
        Scanner scan = new Scanner(System.in);
        for (int y = 0; y < tiles[0].length; y++) {
            for (int x = 0; x < tiles.length; x++) {
                if (x == playerX / scale && y == playerY / scale) {
                    switch (tiles[x][y]) {
                        case 1: // Water
                            System.out.print(Ansi.ansi().fgCyan().a((char) 1) + " ");
                            break;
                        case 2: // Grassland
                            System.out.print(Ansi.ansi().fgBright(Ansi.Color.GREEN).a((char) 1) + " ");
                            break;
                        case 3: // Mountain
                            System.out.print(Ansi.ansi().fgRgb(100, 100, 100).a((char) 1) + " ");
                            break;
                        case 4: // Beach
                            System.out.print(Ansi.ansi().fgYellow().a((char) 1) + " ");
                            break;
                        case 5: // Grassland2
                            System.out.print(Ansi.ansi().fgBright(Ansi.Color.GREEN).a((char) 1) + " ");
                            break;
                        case 6: // Tundra
                            System.out.print(Ansi.ansi().fgRgb(255, 255, 255).a((char) 1) + " ");
                            break;
                        case 7: // Forest
                            System.out.print(Ansi.ansi().fgBright(Ansi.Color.GREEN).a((char) 1) + " ");
                            break;
                        default:
                            System.out.print(Ansi.ansi().bgMagenta().a("  "));
                            break;
                    }
                    System.out.print(Ansi.ansi().reset().toString());
                } else {
                    switch (tiles[x][y]) {
                        case 1: // Water
                            System.out.print(Ansi.ansi().fgCyan().a("~ "));
                            break;
                        case 2: // Grassland
                            System.out.print(Ansi.ansi().fgBright(Ansi.Color.GREEN).a(", "));
                            break;
                        case 3: // Mountain
                            System.out.print(Ansi.ansi().fgRgb(100, 100, 100).a("^ "));
                            break;
                        case 4: // Beach
                            System.out.print(Ansi.ansi().fgYellow().a("# "));
                            break;
                        case 5: // Grassland2
                            System.out.print(Ansi.ansi().fgBright(Ansi.Color.GREEN).a(". "));
                            break;
                        case 6: // Tundra
                            System.out.print(Ansi.ansi().fgRgb(255, 255, 255).a("* "));
                            break;
                        case 7: // Forest
                            System.out.print(Ansi.ansi().fgBright(Ansi.Color.GREEN).a("t "));
                            break;
                        default:
                            System.out.print(Ansi.ansi().bgMagenta().a("  "));
                            break;
                    }
                    System.out.print(Ansi.ansi().reset().toString());
                }
            }
            System.out.println();
        }
        System.out.println("World Statistics:\n" + "Water Tiles: " + world.getWater() + " Grass Tiles: " + world.getGrass() + " \nForest Tiles: " + world.getForests() + " Mountain Tiles: " + world.getMountains() + " \nBeach Tiles: " + world.getBeaches()+ " Tundra Tiles: " + world.getTundras()+ " \nTotal Tiles: " + world.getTotalTiles());
        System.out.println("Enter \"B\" or \"Back\" to return");
        String input = scan.nextLine();
        while (!input.equalsIgnoreCase("back") && !input.equalsIgnoreCase("b")) {
            System.out.println("Enter \"B\" or \"Back\" to return");
            input = scan.nextLine();
        }
    }
}