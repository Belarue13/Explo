import java.util.Random;
import java.util.Scanner;

public class Actions {

    public boolean isAdjacentToWater(Player player, WorldGenerator world) {
        int playerX = player.getX();
        int playerY = player.getY();
        int[][] tiles = world.getTiles();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int x = playerX + dx;
                int y = playerY + dy;
                if (x >= 0 && x < world.getWidth() && y >= 0 && y < world.getHeight()) {
                    if (tiles[x][y] == 1) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean isAdjacentToMountain(Player player, WorldGenerator world) {
        int playerX = player.getX();
        int playerY = player.getY();
        int[][] tiles = world.getTiles();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int x = playerX + dx;
                int y = playerY + dy;
                if (x >= 0 && x < world.getWidth() && y >= 0 && y < world.getHeight()) {
                    if (tiles[x][y] == 3) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean isAdjacentToGrass(Player player, WorldGenerator world) {
        int playerX = player.getX();
        int playerY = player.getY();
        int[][] tiles = world.getTiles();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int x = playerX + dx;
                int y = playerY + dy;
                if (x >= 0 && x < world.getWidth() && y >= 0 && y < world.getHeight()) {
                    if (tiles[x][y] == 2 || tiles[x][y] == 5) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean isAdjacentToForest(Player player, WorldGenerator world) {
        int playerX = player.getX();
        int playerY = player.getY();
        int[][] tiles = world.getTiles();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int x = playerX + dx;
                int y = playerY + dy;
                if (x >= 0 && x < world.getWidth() && y >= 0 && y < world.getHeight()) {
                    if (tiles[x][y] == 7) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean fish(Player player, WorldGenerator world, Character character) {
        int x = player.getX();
        int y = player.getY();
        if (world.getTile(x, y) != 1 && !isAdjacentToWater(player, world)) {
            System.out.println("You need to be next to water to fish.");
            try {
                Thread.sleep(1000); // pause for one second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return false;
        }
        int fishingChance = 25 + character.getFishingLv();
        Random rand = new Random();
        player.increaseHunger();
        player.increaseThirst();
        if (rand.nextInt(100) < fishingChance) {
            character.addItemToInventory("Fish");
            character.addXP("fishing", 3);
            System.out.println("You caught a fish!");
        } else {
            character.addXP("fishing", 1);
            System.out.println("You didn't catch anything.");
        }

        try {
            Thread.sleep(1000); // pause for one second
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean mine(Player player, WorldGenerator world, Character character) {
        int x = player.getX();
        int y = player.getY();
        int mineSpeed = 3000;
        if (world.getTile(x, y) != 3 && !isAdjacentToMountain(player, world)) {
            System.out.println("You need to be next to a mountain to mine.");
            try {
                Thread.sleep(1000); // pause for one second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return false;
        }
        try {
            System.out.println("Mining...");
            Thread.sleep((long) (mineSpeed - (mineSpeed * ((double) (character.getMiningLv())/100)))); // pause for one second
            player.addStone(1);
            character.addXP("mining", 2);
            player.increaseHunger();
            player.increaseThirst();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean chop(Player player, WorldGenerator world, Character character) {
        Random rand = new Random();
        int x = player.getX();
        int y = player.getY();
        int chopSpeed = 3000;
        int appleChance = 10 + character.choppingLv;
        if (world.getTile(x, y) != 7 && !isAdjacentToForest(player, world)) {
            System.out.println("You need to be on or next to a forest to chop.");
            try {
                Thread.sleep(1000); // pause for one second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return false;
        }
        try {
            System.out.println("Chopping...");
            Thread.sleep((long) (chopSpeed - (chopSpeed * ((double) (character.getChoppingLv())/100)))); // pause
            player.addWood(1);
            character.addXP("chopping", 2);
            if (rand.nextInt(100) < appleChance) {
                character.addItemToInventory("Apple");
                character.addXP("chopping", 1);
                System.out.println("You found an Apple!");
                Thread.sleep(1000);
            }
            player.increaseHunger();
            player.increaseThirst();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean drink(Player player, WorldGenerator world, Character character) {
        int x = player.getX();
        int y = player.getY();
        if (world.getTile(x, y) != 1 && !isAdjacentToWater(player, world)) {
            System.out.println("You need to be next to water to drink.");
            try {
                Thread.sleep(1000); // pause for one second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return false;
        }
        try {
            System.out.println("Drinking...");
            Thread.sleep(3000); // pause for one second
            player.decreaseThirst();
            player.increaseHunger();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean eat(Player player, Character character) {
        if (!character.inventory.contains("Apple") && !character.inventory.contains("Fish")) {
            System.out.println("You don't have any food!");
            try {
                Thread.sleep(1000); // pause for one second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return false;
        }
        try {
            System.out.println("Eating...");
            Thread.sleep(3000); // pause for one second
            player.increaseThirst();
            player.decreaseHunger();
            if(character.inventory.contains("Fish")){
                character.inventory.remove("Fish");
            } else if(character.inventory.contains("Apple")){
                character.inventory.remove("Apple");
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }

    public void actionMenu(Player player, WorldGenerator world, Character character){
        System.out.println("+-----------------------------------------------------------+");
        System.out.println("|                          Actions                          |");
        System.out.println("+-----------------------------------------------------------+");
        System.out.println("| 1. Fish       2. Mine       3. Chop       4. Drink        |");
        System.out.println("| 5. Eat                                                    |");
        System.out.println("+-----------------------------------------------------------+");
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter an action or B \"Back\" to close the action menu: ");
        String input = scan.nextLine();
        while (!input.equalsIgnoreCase("back") && !input.equalsIgnoreCase("b") && !input.equalsIgnoreCase("1") && !input.equalsIgnoreCase("2") && !input.equalsIgnoreCase("3") && !input.equalsIgnoreCase("Chop") && !input.equalsIgnoreCase("Mine") && !input.equalsIgnoreCase("Fish") && !input.equalsIgnoreCase("Drink") && !input.equalsIgnoreCase("4") && !input.equalsIgnoreCase("5") && !input.equalsIgnoreCase("eat")){
            System.out.println("Enter an action or B \"Back\" to close the action menu: ");
            input = scan.nextLine();
        }
        if (input.equalsIgnoreCase("fish") || input.equalsIgnoreCase("1")){
            fish(player, world, character);
        }
        if (input.equalsIgnoreCase("mine") || input.equalsIgnoreCase("2")){
            mine(player, world, character);
        }
        if (input.equalsIgnoreCase("chop") || input.equalsIgnoreCase("3")){
            chop(player, world, character);
        }
        if (input.equalsIgnoreCase("drink") || input.equalsIgnoreCase("4")){
            drink(player, world, character);
        }
        if (input.equalsIgnoreCase("eat") || input.equalsIgnoreCase("5")){
            eat(player, character);
        }
    }
}
