import java.io.IOException;
import java.util.Random;
import java.util.Scanner;

public class Actions {

    public double luckBenefit;
    public double strengthBenefit;
    public double charismaticBenefit;
    // Needy is in Player.java

    public void setLuckBenefit(Traits traits) {
        if (traits.isLucky()) {
            luckBenefit = 3;
        } else if (traits.isUnlucky()) {
            luckBenefit = -3;
        } else {
            luckBenefit = 0;
        }
    }

    public void setStrengthBenefit(Traits traits) {
        if (traits.isStrong()) {
            strengthBenefit = 0.5;
        } else if (traits.isWeak()) {
            strengthBenefit = -0.5;
        } else {
            strengthBenefit = 0;
        }
    }

    public void setCharismaticBenefit(Traits traits) {
        if (traits.isCharismatic()) {
            charismaticBenefit = 0.10; // 10 cent +/-
        } else {
            charismaticBenefit = 0;
        }
    }

    public double getCharismaticBenefit() {
        return charismaticBenefit;
    }

    public double getStrengthBenefit() {
        return strengthBenefit;
    }

    public double getLuckBenefit() {
        return luckBenefit;
    }

    public boolean isAdjacentToWater(Player player, WorldGenerator world) {
        int playerX = player.getX();
        int playerY = player.getY();
        int[][] tiles = world.getTiles();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int x = playerX + dx;
                int y = playerY + dy;
                if (x >= 0 && x < world.getWidth() && y >= 0 && y < world.getHeight()) {
                    if (tiles[x][y] == 1) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean isAdjacentToMountain(Player player, WorldGenerator world) {
        int playerX = player.getX();
        int playerY = player.getY();
        int[][] tiles = world.getTiles();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int x = playerX + dx;
                int y = playerY + dy;
                if (x >= 0 && x < world.getWidth() && y >= 0 && y < world.getHeight()) {
                    if (tiles[x][y] == 3) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean isAdjacentToGrass(Player player, WorldGenerator world) {
        int playerX = player.getX();
        int playerY = player.getY();
        int[][] tiles = world.getTiles();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int x = playerX + dx;
                int y = playerY + dy;
                if (x >= 0 && x < world.getWidth() && y >= 0 && y < world.getHeight()) {
                    if (tiles[x][y] == 2 || tiles[x][y] == 5) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean isAdjacentToForest(Player player, WorldGenerator world) {
        int playerX = player.getX();
        int playerY = player.getY();
        int[][] tiles = world.getTiles();
        for (int dx = -1; dx <= 1; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                int x = playerX + dx;
                int y = playerY + dy;
                if (x >= 0 && x < world.getWidth() && y >= 0 && y < world.getHeight()) {
                    if (tiles[x][y] == 7) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    public boolean fish(Player player, WorldGenerator world, Character character, Traits traits) {
        int x = player.getX();
        int y = player.getY();
        if (world.getTile(x, y) != 1 && !isAdjacentToWater(player, world)) {
            System.out.println("You need to be next to water to fish.");
            try {
                Thread.sleep(1000); // pause for one second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return false;
        }
        if (!character.inventory.contains("Worm")) {
            System.out.println("You need a worm to fish.");
            try {
                Thread.sleep(1000); // pause for one second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return false;
        }
        double fishingChance = 25 + character.getFishingLv() + luckBenefit;
        Random rand = new Random();
        System.out.println("Fishing...");
        try {
            Thread.sleep(2000); // pause for one second
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        player.increaseHunger(traits);
        player.increaseThirst(traits);
        if (rand.nextInt(100) <= fishingChance) {
            character.addXP("fishing", 3);
            character.addItemToInventory("Fish");
            System.out.println("You caught a fish!");
        } else {
            character.addXP("fishing", 1);
            System.out.println("You didn't catch anything.");
        }
        character.inventory.remove("Worm");
        try {
            Thread.sleep(1000); // pause for one second
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean mine(Player player, WorldGenerator world, Character character, Traits traits) {
        setStrengthBenefit(traits);
        int x = player.getX();
        int y = player.getY();
        double mineSpeed = 3000;
        double strengthModification = mineSpeed * strengthBenefit;
        mineSpeed = mineSpeed - ((mineSpeed / 100) * character.getMiningLv()) - strengthModification;
        if (world.getTile(x, y) != 3 && !isAdjacentToMountain(player, world)) {
            System.out.println("You need to be next to a mountain to mine.");
            try {
                Thread.sleep(1000); // pause for one second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return false;
        }
        try {
            System.out.println("Mining...");
            Thread.sleep((long) (mineSpeed - (mineSpeed * ((double) (character.getMiningLv()) / 100)))); // pause for one second
            player.addStone(1);
            character.addXP("mining", 2);
            player.increaseHunger(traits);
            player.increaseThirst(traits);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean chop(Player player, WorldGenerator world, Character character, Traits traits) {
        setStrengthBenefit(traits);
        Random rand = new Random();
        int x = player.getX();
        int y = player.getY();
        double chopSpeed = 3000;
        double strengthModification = chopSpeed * strengthBenefit;
        chopSpeed = chopSpeed - ((chopSpeed / 100) * character.getChoppingLv()) - strengthModification;
        double appleChance = 15 + character.choppingLv + luckBenefit;
        if (world.getTile(x, y) != 7 && !isAdjacentToForest(player, world)) {
            System.out.println("You need to be on or next to a forest to chop.");
            try {
                Thread.sleep(1000); // pause for one second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return false;
        }
        try {
            System.out.println("Chopping...");
            Thread.sleep((long) (chopSpeed - (chopSpeed * ((double) (character.getChoppingLv()) / 100)))); // pause
            player.addWood(1);
            character.addXP("chopping", 2);
            if (rand.nextInt(100) <= appleChance) {
                character.addItemToInventory("Apple");
                character.addXP("chopping", 1);
                System.out.println("You found an Apple!");
                Thread.sleep(1000);
            }
            player.increaseHunger(traits);
            player.increaseThirst(traits);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean dig(Player player, WorldGenerator world, Character character, Traits traits) {
        setStrengthBenefit(traits);
        Random rand = new Random();
        int x = player.getX();
        int y = player.getY();
        double digSpeed = 2000;
        double strengthModification = digSpeed * strengthBenefit;
        digSpeed = digSpeed - ((digSpeed / 100) * character.getDiggingLv()) - strengthModification;
        double wormChance = 35 + character.diggingLv + luckBenefit;
        if (world.getTile(x, y) != 7 && !isAdjacentToGrass(player, world)) {
            System.out.println("You need to be on or next to grass to dig.");
            try {
                Thread.sleep(1000); // pause for one second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return false;
        }
        try {
            System.out.println("Digging...");
            Thread.sleep((long) (digSpeed - (digSpeed * ((double) (character.getDiggingLv()) / 100)))); // pause
            character.addXP("digging", 2);
            if (rand.nextInt(100) <= wormChance) {
                character.addItemToInventory("Worm");
                character.addXP("digging", 1);
                System.out.println("You found a Worm!");
                Thread.sleep(1000);
            }
            player.increaseHunger(traits);
            player.increaseThirst(traits);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean drink(Player player, WorldGenerator world, Character character, Traits traits) {
        int x = player.getX();
        int y = player.getY();
        if (world.getTile(x, y) != 1 && !isAdjacentToWater(player, world)) {
            System.out.println("You need to be next to water to drink.");
            try {
                Thread.sleep(1000); // pause for one second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return false;
        }
        try {
            System.out.println("Drinking...");
            Thread.sleep(3000); // pause for one second
            player.decreaseThirst();
            player.increaseHunger(traits);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }

    public boolean eat(Player player, Character character, Traits traits) {
        if (!character.inventory.contains("Apple") && !character.inventory.contains("Fish")) {
            System.out.println("You don't have any food!");
            try {
                Thread.sleep(1000); // pause for one second
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            return false;
        }
        try {
            System.out.println("Eating...");
            Thread.sleep(3000); // pause for one second
            player.increaseThirst(traits);
            player.decreaseHunger();
            if (character.inventory.contains("Fish")) {
                character.inventory.remove("Fish");
            } else if (character.inventory.contains("Apple")) {
                character.inventory.remove("Apple");
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return true;
    }

    public void actionMenu(Player player, WorldGenerator world, Character character, Traits traits) throws IOException, InterruptedException {
        System.out.println("+-----------------------------------------------------------+");
        System.out.println("|                          Actions                          |");
        System.out.println("+-----------------------------------------------------------+");
        System.out.println("| 1. Fish        2. Mine        3. Chop        4. Dig       |");
        System.out.println("| 5. Drink       6. Eat                                     |");
        System.out.println("+-----------------------------------------------------------+");
        Scanner scan = new Scanner(System.in);
        System.out.println("Enter an action or B \"Back\" to close the action menu: ");
        String input = scan.nextLine();
        while (!input.equalsIgnoreCase("B") && !input.equalsIgnoreCase("Back")) {
            if (input.equalsIgnoreCase("fish") || input.equalsIgnoreCase("1")) {
                fish(player, world, character, traits);
            } else if (input.equalsIgnoreCase("mine") || input.equalsIgnoreCase("2")) {
                mine(player, world, character, traits);
            } else if (input.equalsIgnoreCase("chop") || input.equalsIgnoreCase("3")) {
                chop(player, world, character, traits);
            } else if (input.equalsIgnoreCase("drink") || input.equalsIgnoreCase("5")) {
                drink(player, world, character, traits);
            } else if (input.equalsIgnoreCase("eat") || input.equalsIgnoreCase("6")) {
                eat(player, character, traits);
            } else if (input.equalsIgnoreCase("dig") || input.equalsIgnoreCase("4")){
                dig(player, world, character, traits);
            }
            System.out.print("\033[H\033[2J");
            System.out.flush();
            Main.clearConsole();
            world.print(player);
            // Redundant I believe, but gets the job done without error. Might clean up later. Possible while loop
            // for whole method?
            System.out.println("+-----------------------------------------------------------+");
            System.out.println("|                          Actions                          |");
            System.out.println("+-----------------------------------------------------------+");
            System.out.println("| 1. Fish        2. Mine        3. Chop        4. Dig       |");
            System.out.println("| 5. Drink       6. Eat                                     |");
            System.out.println("+-----------------------------------------------------------+");
            System.out.println("Enter an action or B \"Back\" to close the action menu: ");
            input = scan.nextLine();
        }
    }
}
