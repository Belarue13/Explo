import java.io.IOException;
import java.util.Scanner;

public class Merchant {
    public double money = 0;
    double sellFishValue;
    double sellAppleValue;
    double sellWormValue;

    public void getBenefit(Actions actions, Traits traits){
        actions.setCharismaticBenefit(traits);
        sellFishValue = 1.57 + actions.getCharismaticBenefit();
        sellAppleValue = 0.82 + actions.getCharismaticBenefit();
        sellWormValue = 0.08 + actions.getCharismaticBenefit();
    }

    public String merchant =
                "+-----------------------------------------------------------+\n" +
                "|                            Merchant                       |\n" +
                "|                              .-.                          |\n" +
                "|                             (   )                         |\n" +
                "|                             _'-'_                         |\n" +
                "|                            /)`:'(\\                        |\n" +
                "|                           //| : |\\\\                       |\n" +
                "|                             |-'-|                         |\n" +
                "|                             | | |                         |\n" +
                "|                             |_|_|                         |\n" +
                "|                                                           |";


    public double getSellFishValue(){
        return sellFishValue;
    }
    public double getSellAppleValue(){
        return sellAppleValue;
    }

    public double getSellWormValue(){
        return sellWormValue;
    }

    public double getBalance(){
        money = Math.round(money*100);
        money = money/100;
        return money;
    }

    public boolean sell(Character character) throws IOException, InterruptedException {
        Scanner input = new Scanner(System.in);
        System.out.println(merchant);
        character.inventoryMenu();
        while (true) {
            System.out.println("Enter the name of the item you'd like to sell, or enter B to go Back");
            String item = input.nextLine();
            if (item.equalsIgnoreCase("b") || item.equalsIgnoreCase("back")) {
                return false;
            } else {
                if (item.equalsIgnoreCase("Apple")) {
                    if(character.inventory.contains("Apple")){
                        character.inventory.remove("Apple");
                        money = money + getSellAppleValue();
                        System.out.println("Sold 1 Apple");
                    } else{
                        try {
                            System.out.println("You dont have an Apple...");
                            Thread.sleep(1000); // pause for one second
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (item.equalsIgnoreCase("Worm")) {
                    if(character.inventory.contains("Worm")){
                        character.inventory.remove("Worm");
                        money = money + getSellWormValue();
                        System.out.println("Sold 1 Worm");
                    } else{
                        try {
                            System.out.println("You dont have a Worm...");
                            Thread.sleep(1000); // pause for one second
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (item.equalsIgnoreCase("Fish")) {
                    if(character.inventory.contains("Fish")){
                        character.inventory.remove("Fish");
                        money = money + getSellFishValue();
                        System.out.println("Sold 1 Fish");
                    } else{
                        try {
                            System.out.println("You dont have a Fish...");
                            Thread.sleep(1000); // pause for one second
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
            System.out.print("\033[H\033[2J");
            System.out.flush();
            Main.clearConsole();
            System.out.println(merchant);
            character.inventoryMenu();
        }
    }

}
