import java.util.Scanner;

public class Merchant {

    public double fishValue = 1.57;
    public double appleValue = 0.82;
    public double money = 0;

    public String merchant =
                "+-----------------------------------------------------------+\n" +
                "|                            Merchant                       |\n" +
                "|                              .-.                          |\n" +
                "|                             (   )                         |\n" +
                "|                             _'-'_                         |\n" +
                "|                            /)`:'(\\                        |\n" +
                "|                           //| : |\\\\                       |\n" +
                "|                             |-'-|                         |\n" +
                "|                             | | |                         |\n" +
                "|                             |_|_|                         |\n" +
                "|                                                           |";


    public double getFishValue(){
        return fishValue;
    }
    public double getAppleValue(){
        return appleValue;
    }

    public double getBalance(){
        return money;
    }

    public boolean sell(Character character) {
        Scanner input = new Scanner(System.in);
        System.out.println(merchant);
        character.inventoryMenu();
        while (true) {
            System.out.println("Enter the name of the item you'd like to sell, or enter B to go Back");
            String item = input.nextLine();
            if (item.equalsIgnoreCase("b") || item.equalsIgnoreCase("back")) {
                return false;
            } else {
                if (item.equalsIgnoreCase("Apple")) {
                    if(character.inventory.contains("Apple")){
                        character.inventory.remove("Apple");
                        money = money + getAppleValue();
                        return true;
                    } else{
                        try {
                            System.out.println("You dont have an Apple...");
                            Thread.sleep(1000); // pause for one second
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
                if (item.equalsIgnoreCase("Fish")) {
                    if(character.inventory.contains("Fish")){
                        character.inventory.remove("Fish");
                        money = money + getFishValue();
                        return true;
                    } else{
                        try {
                            System.out.println("You dont have a Fish...");
                            Thread.sleep(1000); // pause for one second
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }
        }
    }

}
